// inject_build_id.js
const fs = require('fs');
const path = require('path');
const BUILD_ID = process.env.BUILD_ID || 'local-dev';
const SPEC_SHA = process.env.SPEC_SHA || '0000000';
const entryPath = path.resolve('frontend/index.html');
if (!fs.existsSync(entryPath)) process.exit(0);
let html = fs.readFileSync(entryPath, 'utf8');
html = html.replace(/<!-- BUILD_ID:.*? -->/, `<!-- BUILD_ID:${BUILD_ID}|SHA:${SPEC_SHA} -->`);
fs.writeFileSync(entryPath, html);
console.log('BUILD_ID injected successfully.');
