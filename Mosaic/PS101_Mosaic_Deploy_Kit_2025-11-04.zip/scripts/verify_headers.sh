#!/bin/zsh
set -euo pipefail
SITE="https://whatismydelta.com"
curl -I "$SITE"
