// Mosaic Platform - Main Initialization Module
// Follows AI Frontend DOM Timing Playbook

// Configuration
const API_BASE = 'https://what-is-my-delta-site-production.up.railway.app';
const SESSION_KEY = 'delta_session_id';
const USER_DATA_KEY = 'delta_user_data';
const TRIAL_START_KEY = 'delta_trial_start';
const TRIAL_DURATION = 5 * 60 * 1000; // 5 minutes

// Selector helper
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

// Module state
let booted = false;
let sessionId = '';
let isAuthenticated = false;
let currentUser = null;
let trialStartTime = null;

// Idempotent initialization function
export function initApp() {
  if (booted) return;
  booted = true;

  console.log('[INIT] Starting application initialization...');

  try {
    // Phase 1: Load session from localStorage
    console.log('[INIT] Phase 1: Loading session...');
    sessionId = localStorage.getItem(SESSION_KEY) || '';
    trialStartTime = localStorage.getItem(TRIAL_START_KEY);

    if (sessionId) {
      document.body.dataset.session = sessionId;
      console.log('[INIT] Session found');
    } else if (!trialStartTime) {
      console.log('[INIT] Starting trial');
      trialStartTime = Date.now().toString();
      localStorage.setItem(TRIAL_START_KEY, trialStartTime);
    }

    // Phase 2: Initialize UI elements with null-guards
    console.log('[INIT] Phase 2: Initializing UI...');

    // Footer year
    const yearEl = $('#y');
    if (yearEl) yearEl.textContent = new Date().getFullYear();

    // API status check
    const apiStatus = $('#apiStatus');
    if (apiStatus) {
      checkAPI();
      setInterval(() => {
        if (apiStatus.className.includes('error')) {
          checkAPI();
        }
      }, 30000);
    }

    // Phase 3: Setup chat system
    console.log('[INIT] Phase 3: Setting up chat...');
    setupChat();

    // Phase 4: Setup navigation and links
    console.log('[INIT] Phase 4: Setting up navigation...');
    setupNavigation();

    console.log('[INIT] Initialization complete');
  } catch (error) {
    console.error('[INIT] Initialization failed:', error);
  }
}

// API health check
async function checkAPI() {
  const apiStatus = $('#apiStatus');
  if (!apiStatus) return;

  try {
    const response = await fetch(`${API_BASE}/health`, {
      method: 'GET',
      signal: AbortSignal.timeout(5000)
    });

    if (response.ok) {
      const data = await response.json();
      if (data.ok) {
        apiStatus.textContent = 'ready';
        apiStatus.className = 'status working';
        return;
      }
    }
    throw new Error('API not responding');
  } catch (error) {
    apiStatus.textContent = 'offline';
    apiStatus.className = 'status error';
    console.warn('[INIT] API check failed:', error.message);
  }
}

// Chat system setup
function setupChat() {
  const chat = $('#chat');
  const chatInput = $('#chatInput');
  const chatLog = $('#chatLog');
  const sendBtn = $('#sendMsg');
  const openBtn = $('#openChat');
  const closeBtn = $('#closeChat');

  if (!chat) return;

  // Open chat
  if (openBtn && chatInput) {
    openBtn.addEventListener('click', (e) => {
      e.preventDefault();
      chat.style.display = 'block';
      chatInput.focus();
    });
  }

  // Close chat
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      chat.style.display = 'none';
    });
  }

  // Close on Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && chat.style.display === 'block') {
      chat.style.display = 'none';
    }
  });

  // Send message
  if (sendBtn && chatInput && chatLog) {
    const sendMessage = async () => {
      const message = chatInput.value.trim();
      if (!message) return;

      // Add user message
      addMessage(message, 'you');
      chatInput.value = '';

      // Add loading indicator
      const loadingDiv = document.createElement('div');
      loadingDiv.className = 'msg loading';
      loadingDiv.textContent = 'thinking...';
      chatLog.appendChild(loadingDiv);
      chatLog.scrollTop = chatLog.scrollHeight;

      try {
        const response = await fetch(`${API_BASE}/wimd`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: message }),
          signal: AbortSignal.timeout(15000)
        });

        chatLog.removeChild(loadingDiv);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();
        addMessage(data.message || 'No response', 'bot');
      } catch (error) {
        chatLog.removeChild(loadingDiv);
        addMessage('Error: ' + error.message, 'bot');
      }
    };

    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });
  }

  function addMessage(text, who = 'you') {
    const div = document.createElement('div');
    div.className = `msg ${who}`;
    div.textContent = (who === 'you' ? '> ' : '') + text;
    if (chatLog) {
      chatLog.appendChild(div);
      chatLog.scrollTop = chatLog.scrollHeight;
    }
  }
}

// Navigation setup
function setupNavigation() {
  // Data-prompt links
  $$('[data-prompt]').forEach(link => {
    link.addEventListener('click', async (e) => {
      e.preventDefault();
      const prompt = link.dataset.prompt;
      if (prompt) {
        const coachAsk = $('#coachAsk');
        if (coachAsk) coachAsk.value = prompt;
      }
    });
  });

  // Internal anchor links
  $$('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const target = $(link.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// Belt and suspenders: DOMContentLoaded + defer
document.addEventListener('DOMContentLoaded', initApp, { once: true });

// Expose for testing/debugging
window.initApp = initApp;
window.Mosaic = { initApp, API_BASE };
