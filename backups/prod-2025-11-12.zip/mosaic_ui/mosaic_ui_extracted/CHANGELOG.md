# CHANGELOG.md

- 2025-09-11 19:24 — Initial pack: unified demo page, welcome/intro, Fast Track/Discovery, metrics,
  modules, coach strip + chat, upload modal, feedback form,
  save/load + autosave, leave guard, clickable intro/journey + module anchors.
