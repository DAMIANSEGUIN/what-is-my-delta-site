# 📝 WIMD Railway Deploy – Context Note

> Action on Restart: run ~/restart_wimd.sh (auto-logs status; URL saved in wimd_config.sh)

## Required Env Vars (Railway → Variables)
OPENAI_API_KEY=sk-xxx
CLAUDE_API_KEY=sk-ant-xxx
PUBLIC_SITE_ORIGIN=https://whatismydelta.com
PUBLIC_API_BASE=
DATABASE_URL=
SENTRY_DSN=
