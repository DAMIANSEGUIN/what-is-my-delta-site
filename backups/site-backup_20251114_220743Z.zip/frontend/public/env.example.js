// Copy this file to public/env.js and fill in your Supabase details.
// If this file is missing, the app runs in LocalStorage-only mode.
window.__ENV = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-KEY"
};